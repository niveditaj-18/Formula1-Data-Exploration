Team 6 
Project title: Data-Driven Exploration of Formula 1 Race Strategies Using Machine Learning

Full data cleaning and machine learning models are in the jupyter file: ML modeling.ipynb
Other visualizations are in the following files: Visualizations.ipynb, Visualization1.ipynb, Visualizations2.ipynb.
Tableu visualizations are in the tableu workbook: Visualizations.twb
